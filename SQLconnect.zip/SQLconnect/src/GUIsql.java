import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

public class GUIsql extends JDialog {
    private JTextField textFieldM;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
    private JTextField textField5;
    private JTextField textField6;
    private JLabel L1;
    private JLabel L2;
    private JLabel L3;
    private JLabel L4;
    private JLabel L5;
    private JLabel L6;
    private JButton enterButton;
    private JButton buttonCancel;
    private JPanel MyPanel;



    public GUIsql(JFrame parent) {
        super(parent);
        setTitle("Connect to SQL");
        setContentPane(MyPanel);
        setMinimumSize(new Dimension(450, 474));
        setModal(true);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);


        enterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GUIuser();
            }
        });
        buttonCancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        setVisible(true);
    }

    private void GUIuser() {
        String firstName = textFieldM.getText();
        String lastName = textField2.getText();
        String userName = textField3.getText();
        String password = String.valueOf(textField4.getText());
        String email = textField5.getText();
        String mobileNumber = textField6.getText();

        if (firstName.isEmpty() || lastName.isEmpty() || userName.isEmpty() || password.isEmpty() || email.isEmpty() || mobileNumber.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter all fields", "Try again", JOptionPane.ERROR_MESSAGE);
            return;
        }

        account = addAccountToDatabase(firstName, lastName, userName, password, email, mobileNumber);
        if (account != null) {
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to create a new account", "Try again", JOptionPane.ERROR_MESSAGE);
        }
    }

    public Account account;

    private Account addAccountToDatabase(String firstName, String lastName, String userName, String password, String email, String mobileNumber) {
        Account account = null;
        final String DB_URL = "jdbc:mysql://localhost:3306/swing_demo?serverTimezone=UTC";      // Enter the URL of the database
        final String USERNAME = "root"; // Enter the user name of the database, usually root
        final String PASSWORD = "Zjm200249@szboy"; // Enter the password of the database

        try {
            Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            // Connected to database successfully...

            Statement stmt = conn.createStatement();
            String sql = "INSERT INTO account (first_name, last_name, user_name, password, email_id, mobile_number)" + "VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, firstName);
            preparedStatement.setString(2, lastName);
            preparedStatement.setString(3, userName);
            preparedStatement.setString(4, password);
            preparedStatement.setString(5, email);
            preparedStatement.setString(6, mobileNumber);

            int addedRows = preparedStatement.executeUpdate();
            if (addedRows > 0) {
                account = new Account();
                account.firstName = firstName;
                account.lastName = lastName;
                account.email = email;
                account.password = password;
                account.userName = userName;
                account.mobileNumber = mobileNumber;
            }

            stmt.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return account;
    }

    public static void main(String[] args) {
        GUIsql guIsql = new GUIsql(null);
        Account account = guIsql.account;
        if (account != null) {
            System.out.println("Successful creation of: " + account.userName);
        } else {
            System.out.println("Creation canceled");
        }
    }

}
