public class Account {
    public String firstName;
    public String lastName;
    public String userName;
    public String password;
    public String email;
    public String mobileNumber;
}
